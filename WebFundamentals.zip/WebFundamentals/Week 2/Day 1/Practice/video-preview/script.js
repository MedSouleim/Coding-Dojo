console.log("page loaded...");
function mute(element){
    if(element.muted==true){
        element.muted=false;
    }else{
        element.muted=true;
    }
}