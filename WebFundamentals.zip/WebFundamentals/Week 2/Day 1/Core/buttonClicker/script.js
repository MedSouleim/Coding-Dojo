function Logout(element) {
    element.innerText = "Logout";
  }
  function removeBtn(element) {
    element.remove();
  }
  function alertThis(element) {
    console.log("Ninja was liked");
    alert("Ninja was liked");
  }